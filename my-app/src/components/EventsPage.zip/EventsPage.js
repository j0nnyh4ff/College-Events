import React, {useState} from 'react';
import {db} from './DatabaseContext';
import './styles/EventsPage.css';
const { remoteConfig } = require("firebase");

 class EventsPage extends React.Component {
     constructor(props) {
         super(props);
         this.state = {events: []};

     }
    
    
    componentDidMount() {
        const eventsRef = db.collectionGroup('events').get();
        
        eventsRef.then(function(querySnapshot) {
                querySnapshot.forEach(function(doc){
                    var joined = []; //this.state.events.push(doc.data());
                    this.setState({ events: joined });
                })
            });
        
    }

    
    render() {
    return (
            <div className="results-container">
                <div className="results-wrapper">
                    <ul>
                        <div className="list-div"><li>Event</li></div>
                        <div className="list-div"><li>Event</li></div>
                        {this.state.events.map(event => (
                            <div className="list-div">
                                <li key={event.id}>{event['eventName']}</li>
                            </div>
                        ))}
                        <li>{this.state.events.length}</li>
                        
                    </ul>
                </div>
            </div>
        );
    }
}

export default EventsPage;